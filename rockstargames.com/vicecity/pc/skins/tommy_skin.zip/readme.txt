Exclusive Tommy Vercetti Skin Installation Instructions

1.  If you have not already done so, unzip the skin to your GTA: Vice City skins folder (by default, C:\Program Files\Rockstar Games\Grand Theft Auto Vice City\skins).

2.  If you have already unzipped the file to another folder, simply copy and paste it into your GTA: Vice City skins folder.

3.  Start the game.

4.  Select "Options," "Player Skin Setup," select the new skin and click "Use Skin".
